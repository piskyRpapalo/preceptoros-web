# Entorno controlado de estudio · PreceptorOS

Esto es el molde de UN espacio de estudio. No es una simulacion: es el esquema
real con el que el rack del Soberano corre sus propios espacios.

## Que hay aqui

  esquema.sql    El canal del espacio: de donde entran los turnos, con su firma
                 Ed25519, su `fuente` y su `arnes`. Se lee entero.
  checkpoint.md  Los criterios con los que se juzga lo que entra en ESE espacio.
                 Cada espacio tiene los suyos y estan escritos, no implicitos.
  rag.md         Por que aqui NO hay un esquema del RAG, y el fallo que lo
                 enseno. Vale mas que un esquema correcto.
  progreso/      Vacio a proposito: es append-only, y lo llena el uso.

## Que NO hay, y por que

No hay una base de datos hecha. Un `.db` es DATO y el dato soberano no se
reparte; el esquema si es codigo y se audita leyendolo. Tu `rag.db` lo crea
`memory.crear()` en tu maquina, con el esquema exacto que espera `recuperar()`.

No hay modelo. Los adaptadores se descargan aparte, cada uno con su sha256.

## Como se comprueba que esto es lo que dice ser

    sha256sum -c entorno-estudio-v1.tar.gz.sha256

Si no cuadra, no lo uses. Dos ficheros con el mismo nombre no son el mismo
fichero, y por eso el hash viaja al lado.
